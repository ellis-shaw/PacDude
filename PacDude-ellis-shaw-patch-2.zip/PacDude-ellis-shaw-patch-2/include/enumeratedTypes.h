#pragma once
enum EDirection { N, S, E, W };
enum ETerrain { Wall, Open, Wood, Water };