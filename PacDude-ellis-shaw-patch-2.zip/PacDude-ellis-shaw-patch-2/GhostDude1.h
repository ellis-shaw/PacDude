#pragma once
#include "GhostDude.h"

class CGhostDude1 : CGhostDude
{
	int delay = 1000;
	int counter = 0;
	void PathFind();
};

void CGhostDude1::PathFind()
{
	if (counter > delay)
	{
		counter = 0;

		switch (mDirection)
		{
		case N:
			mDirection = E;
			break;
		case E:
			mDirection = S;
			break;
		case S:
			mDirection = W;
			break;
		case W:
			mDirection = N;
			break;
		}
	}
	else
	{
		counter++;
	}
}