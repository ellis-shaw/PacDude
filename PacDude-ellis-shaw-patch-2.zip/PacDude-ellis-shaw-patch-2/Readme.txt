===============================================================================
           TL-Wizard : "ProfSkillsRefactor" Project Overview
===============================================================================

This project has been created for you as a starting point for your program.
It uses the TL-Engine to provide a simple interface to a 3D engine.

Summary of the files in the project:

ReadMe.txt
	The file you are reading now.
	
ProfSkillsRefactor.cpp
    This is the main program file. It already has the basic program code to
    initialise a 3D engine. You need to add extra code to load and position the
    objects in your scene, and to set up a camera. You can also add code to 
    move, animate and control the objects and camera.